//Completar las condiciones de los IF para que los mensajes
//se muestren de forma correcta

var numero1=5;
const num2=8; 
const num1=5;
if (num1<num2){
    //alert (num1 +" no es mayor que "+ num2);
}

if (num2>0){
    //alert (num2 +" es positivo ");
}

if (num1<0 || num1 !=0){
    //alert (num1 +" es negativo o distinto de 0 ");
}

++numero1;
if (numero1 <= num2){
    alert ("Incrementar en 1 el valor de " + num1 + " no lo hace mayor o igual que " + num2);
}